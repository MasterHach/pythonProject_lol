from setuptools import setup, find_packages

setup(name='funniest',
      version='0.2',
      py_modules= ['pythonProject_lol'],
      packages=find_packages(),
      include_package_data=True
      )