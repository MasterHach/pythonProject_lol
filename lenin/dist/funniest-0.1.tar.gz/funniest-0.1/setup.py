from setuptools import setup

setup(name='funniest',
      version='0.1',
      )